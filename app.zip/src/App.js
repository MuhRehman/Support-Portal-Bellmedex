
import './App.css';
import Dashboard from './/Pages/Dashboard.jsx';

function App() {
  return (
    <div className="App">
      <Dashboard></Dashboard>
    </div>
  );
}

export default App;
